# HCDE 439 Physical Computing Winter 2021

**Instructor:** Nadya Peek

**Teaching assistant:** Blair Subbaraman

This is an example of a student page for HCDE439. Feel free to use this as a template, or create your own!
